import React from "react";

const Historia = (props) => {
    return <>
        <div className={"historia"}>{props.historia}</div>
    </>
}

export default Historia;