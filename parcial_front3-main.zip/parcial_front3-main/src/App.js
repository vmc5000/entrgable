import Game from './components/Game';

function App() {
  return (
    <Game className="layout"/>
  );
}

export default App;
